# Load necessary libraries
library(readr)
library(utils)

# Specify the path to the zip file
zip_file <- "Employee_Profile.zip"

# Specify the folder where you want to extract the contents
extract_folder <- "Employee_Profile"

# Create the folder if it doesn't exist
if (!file.exists(extract_folder)) {
  dir.create(extract_folder)
}

# Unzip the folder
unzip(zip_file, exdir = extract_folder)

# Now, read the CSV file inside the extracted folder
csv_file <- paste0(extract_folder, "/John Doe_details.csv")  # Adjust the filename as needed

# Read the CSV file into a data frame
employee_data <- read_csv(csv_file)

# Display the data
print(employee_data)
